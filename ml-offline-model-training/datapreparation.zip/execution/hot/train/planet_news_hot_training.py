# -*- coding: utf-8 -*-
import os
import sys
sys.path.insert(0, 'offline-model.zip')

from src.options.train_options import TrainLinUCBOptions
from src_v2.factory.planet_news.planet_news_hot import PlanetNewsHotLinUCBFactory
from utils import download_blob, dump_pickle, read_pickle
from src.validation.cross_validation import cross_validation


def stop_run():
    return 1/0


if __name__ == '__main__':
    # Parse arguments & store checkpoint
    opt = TrainLinUCBOptions().parse()

    # basic option
    opt.experiment_name = 'test'
    base_path = f'{opt.checkpoints_dir}/{opt.experiment_name}'
    bucket_storage = f'machine-learning-models-{opt.project_id}'
    print('base_path : ', base_path)
    print('opt.experiment_name : ', opt.experiment_name)

    # initialize factory and training parameters
    planet_news_hot_linucb_factory = PlanetNewsHotLinUCBFactory(mode='train', use_cuda=True, **vars(opt))

    # download and read dataset
    if opt.download_dataset:
        file_to_download = [opt.dataset, planet_news_hot_linucb_factory.config.COL2CATS_NAMES]

        for file in file_to_download:
            #logger.info(f'[Jollybuy Goods User2Item][Data Preprocessing] Download {file} from the bucket')
            download_blob(bucket_name=bucket_storage,
                          source_blob_name=f'{opt.dataset_blob_path}/{base_path}/{file}',
                          destination_file_name=f'{opt.dataroot}/{file}')

    dataset = read_pickle(file_name='dataset.pickle', base_path=opt.dataroot)
    all_cats = read_pickle(file_name=planet_news_hot_linucb_factory.config.COL2CATS_NAMES, base_path=opt.dataroot)


    # train
    train_params = {'batch_size': opt.batch_size, 'epochs': opt.epochs, 'verbose': opt.verbose}
    p, r, f, auc, roc_curve_info, ndcg = cross_validation(planet_news_hot_linucb_factory, dataset,
                                                          dataset['reward'], train_params=train_params,
                                                          groupby_key=planet_news_hot_linucb_factory.config.NDCG_GROUPBY_KEY,
                                                          random_state=opt.seed, **vars(opt))
    # eval
    validation_result = {
        'val_precision': p[1],
        'val_recall': r[1],
        'val_f1': f[1],
        'val_auc': auc[0]
    }


    '''
    dataset type :  <class 'pandas.core.frame.DataFrame'>
    all_cats type :  <class 'collections.defaultdict'>
        date  ...                                     content_id_neg
    0  20230208  ...  [1623172081384427520, 1588060066211172352, 162...
    1  20230209  ...  [1612366871674228736, 1605786547678875648, 160...
    2  20230209  ...  [1623172081384427520, 1622528321000574976, 160...

    [3 rows x 17 columns]
    Index(['date', 'content_id', 'reward', 'planet_home_page_impression',
        'planet_content_impression', 'home_page_impression',
        'exploration_page_content_impression', 'planet_content_click',
        'home_page_content_click', 'exploration_page_content_click',
        '1_last_day_total_view_count', '3_last_day_total_view_count',
        '7_last_day_total_view_count', '30_last_day_total_view_count', 'cat0',
        'cat1', 'content_id_neg'],
        dtype='object')
    dict_keys(['cat0', 'cat1', 'tags'])
    '''

    ['reward']

        'REQUISITE_COLS': ['age', 'gender', 'cat0', 'cat1', 'final_score',
                       'user_title_embedding', 'item_title_embedding',
                       'cat0_pref_score', 'cat1_pref_score', 'tag_other_pref_score',
                       'hist_cat0', 'seq_length_cat0', 'hist_cat1', 'seq_length_cat1',
                       'y'],