import pandas as pd
import numpy as np
from typing import Union

from utils.logger import logger
from src_v2.configs.planet_news.planet_news_hot import PlanetNewsHotLinUCBConfig
from src_v2.preprocess.planet_news.planet_news_hot import PlanetNewsHotLinUCBPreprocessor
from src_v2.handler.din_handler import DINHandler
from src_v2.factory import CTRRankerFactory



class PlanetNewsHotLinUCBFactory(CTRRankerFactory):

    def __init__(self, mode: str = 'train', col2label2idx: dict = None, model_path: str = '/ml-model', **kwargs):

        assert mode in self.MODE, 'only support train, validation and inference mode'
        self.mode = mode
        self.initialize(self.mode, col2label2idx=col2label2idx, model_path=model_path, **kwargs)

    def initialize(self, mode: str, col2label2idx: dict = None, **kwargs):

        self.config = PlanetNewsHotLinUCBConfig

        if mode == 'train':
            self.preprocessor = PlanetNewsHotLinUCBPreprocessor(configs=self.config,
                                                                      col2label2idx=col2label2idx,
                                                                      mode=mode,
                                                                      **kwargs)
            self.model_params = kwargs
        else:
            if mode == 'inference':
                self.config.REQUISITE_COLS.remove('y')

            self.preprocessor = PlanetNewsHotLinUCBPreprocessor(configs=self.config,
                                                                      col2label2idx=col2label2idx,
                                                                      mode=mode)
            self.model_handler = DINHandler(col2label2idx=self.preprocessor.col2label2idx,
                                            config=self.config,
                                            mode=mode,
                                            use_cuda=False,
                                            **self.config.MODEL_PARAMS)
            self.model_handler.load_model(kwargs.get('model_path', '/ml-model/hot/planet_news/linucb/model.latest.pickle'))

    def train(self, dataset: pd.DataFrame, y_true: Union[pd.Series, np.array, list], train_params: dict = None, **kwargs):

        dataset = self.preprocessor.process(dataset=dataset,
                                            requisite_cols=kwargs.get('requisite_cols', None),
                                            **kwargs)

        self.processed_dataset = dataset
        logger.info(f'Processed data columns: {dataset.columns} \nProcessed data: \n {dataset.iloc[len(dataset) // 3]}')

        self.model_handler = DINHandler(col2label2idx=self.preprocessor.col2label2idx,
                                        config=self.config,
                                        mode=self.mode,
                                        **self.model_params)
        self.model_handler.train(x_train=dataset, y_train=y_true, train_params=train_params)

    def predict(self, dataset, user_data=None, realtime_user_data=None, **kwargs):

        dataset = self.preprocessor.process(dataset, user_data=user_data, realtime_user_data=realtime_user_data, **kwargs)
        scores = self.model_handler.predict(dataset).reshape(-1)

        return scores




