import json
import pandas as pd

from utils.logger import logger
from src.preprocess.utils import convert_type, read_pickle, normalize_data, process_time_period, merge_data_with_user
from src.preprocess.utils.encoder import CategoricalEncoder
from src_v2.preprocess.utils.preference import Preference
from src_v2.preprocess.utils.din import get_behavior_feature
from src_v2.configs import Config


class BaseHotPreprocessor():

    MODE = ['train', 'validation', 'inference']

    def __init__(self, configs=Config({}), col2label2idx=None, logger=logger, mode='train'):

        assert mode in self.MODE, 'only support train, validation and inference mode'

        self.configs = configs
        self.col2label2idx = col2label2idx if col2label2idx else {}
        self.mode = mode
        self.logger = logger
        self.verbose = self.mode != 'inference'

    def process(self, dataset: pd.DataFrame = None, user_data: pd.DataFrame = None, realtime_user_data: pd.Series = None,
                chain_configs: dict = None, requisite_cols: list = None, **kwargs):

        chain_configs = self.configs.CHAIN_CONFIGS if chain_configs is None else chain_configs
        requisite_cols = self.configs.REQUISITE_COLS if requisite_cols is None else requisite_cols

        for func_name, func_params in chain_configs.items():

            if self.mode in func_params.get('disable_mode', []):
                continue

            try:
                chain_func = getattr(self, func_name)
            except ModuleNotFoundError:
                logger.error(f'Module {func_name} not found.')

            func_kwargs = {**kwargs, **func_params, 'user_data': user_data, 'realtime_user_data': realtime_user_data}
            dataset = chain_func(dataset=dataset, **func_kwargs)

        return dataset[requisite_cols]
