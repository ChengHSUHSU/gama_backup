from bdds_recommendation.src_v2.configs import Config


BaseSGDConfigs = Config({
})
